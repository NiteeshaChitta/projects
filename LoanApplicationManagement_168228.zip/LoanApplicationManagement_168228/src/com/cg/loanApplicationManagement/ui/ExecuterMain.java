package com.cg.loanApplicationManagement.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.bean.CustomerDto;
import com.cg.bean.LoanDto;
import com.cg.exceptions.LoanExceptions;

import com.cg.service.ServiceClass;

public class ExecuterMain {
	private static Scanner sc;

	public static void main(String[] args) throws LoanExceptions, SQLException {
		sc = new Scanner(System.in);
		System.out.println("XYZ Finance Company Welcomes You");

		startProgram();
	}

	public static void startProgram() throws LoanExceptions, SQLException {
		 ServiceClass s1 = new ServiceClass();

		String choice;
		String ch;
		// String ch1;
		while (true) {
			System.out.println("\n Enter your choice");
			System.out.println("1. Register Customer");

			System.out.println("2. Exit");

			choice = sc.next().trim();
			switch (choice) {
			case "1":
				RegisterCustomer();
				break;
			case "2":
				// Exit();

				System.out.println("\n \n Thank u!!!");
				System.exit(0);
				break;
			default:
				System.out.println("Choose valid choice");
				break;
			}
		
			
			
	}

	}
	private static void RegisterCustomer() throws LoanExceptions, SQLException {
		// TODO Auto-generated method stub
		
		 ServiceClass s1 = new ServiceClass();
		 LoanDto loan = new LoanDto();
		Customer c1 = new Customer();
		
		while (true) {
			System.out.println("Enter customer Name");
			String Name = sc.next();

			if (s1.ValidateCustomerName(Name) == true) {
				c1.setCusName(Name);
				System.out.println("customer :" + c1.getCusName());
				break;
			} else {
				System.out.println("invalid customer name");

			}
		}
		while (true) {
			System.out.println("Enter customer mail");
			String mail = sc.next();

			if (s1.ValidateMailId(mail) == true) {
				c1.setEmail(mail);
				System.out.println("mail :" + c1.getEmail());
				break;
			} else {
				System.out.println("invalid customer mail");

			}
		}
		while (true) {
			System.out.println("Enter customer no");
			String phno = sc.next();

			if (s1.ValidatePhoneNumber(phno) == true) {
				c1.setMobile(phno);
				System.out.println("Phno :" + c1.getMobile());
				break;
			} else {
				System.out.println("invalid customer no");

			}
		}
		while (true) {
			System.out.println("Enter customer address");
			String addrs = sc.next();

			if (s1.ValidateAddress(addrs) == true) {
				c1.setAddress(addrs);
				System.out.println("address :" + c1.getAddress());
				break;
			} else {
				System.out.println("invalid customer address");

			}

		}
		s1.InsertCust(c1);
		System.out.println(c1.getCusId());
		System.out.println("customer detials are inserted");
		
		System.out.println("do u want to apply loan Y/N");
		String Ch1;
		Ch1 = sc.next();
		switch (Ch1) {
		case "Y":
			System.out.println("Enter the loan Amount");
			double loanAmount = sc.nextDouble();
			loan.setLoanAmount(loanAmount);

			System.out.println("Enter the loan Duration");
			int loanDuration = sc.nextInt();

		

			double RateOfInterest = 9.5;

			loan.setDuration(loanDuration);
//			System.out.println("loan Duration :" + " " + l1.getDuration());
			double EMI = loanAmount * RateOfInterest * loanDuration
					* (1 + RateOfInterest)
					/ ((1 + RateOfInterest) * loanDuration - 1);
			System.out.println("for loan amount" + " " + loanAmount
					+ "and no of years" + loanDuration
					+ "your EMI per month will be" + EMI);
		
		
			System.out.println("do u want to continue YES/NO");
			String chi;
			chi=sc.next();
			
			switch(chi){
			
			case "YES":
			s1.applyLoan(loan);
			System.out.println("your loan request is generated");
			System.out.println("ur loan id" + s1.getloanID());
			break;
		case "NO":
			System.out.println("thanku");
			System.exit(0);
			break;
			}
		break;
		case "N":
			
			show();
			System.exit(0);
		
		break;
		
		}
	}
		

	private static void show() throws LoanExceptions, SQLException {
		// TODO Auto-generated method stub
		
		 ServiceClass s1 = new ServiceClass();

ArrayList<Customer> ar= new ArrayList<Customer>();
ar=s1.getdetails();
Iterator<Customer> it = ar.iterator();
if(it!=null)
{

	while(it.hasNext())
		
	{
		Customer obj = (Customer) it.next();
		System.out.print(obj.getCusId()+"  ");
		System.out.print(obj.getCusName()+"  ");
		System.out.print(obj.getAddress()+"  ");
		System.out.print(obj.getMobile()+"  ");
		System.out.print(obj.getEmail()+"  ");
		
		System.out.println();
		
	}

}
	}}

















