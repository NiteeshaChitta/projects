package com.cg.loanApplicationManagement.service;

public interface IServiceClass {
	 boolean ValidateCustomerName(String custerName);
	 boolean ValidateMailId(String mailId);
	 boolean ValidatePhoneNumber(String phoneNum);
	boolean ValidateAddress(String cusAddrs);
	//boolean ValidatePhoneNumber(long phno);
}
