package com.capgemini.loanApplicationManagement.exception;

public class LoanExceptions extends Exception {
	public LoanExceptions(String msg) {
		super(msg);
	}

}
