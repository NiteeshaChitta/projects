package com.capgemini.loanApplicationManagement.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystemNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.loanApplicationManagement.exception.LoanExceptions;

public class DBConnecton {
	static Connection conn = null;

	public static Connection getConnection() throws LoanExceptions {
		if (conn == null) {
			try {
				File src = new File("Resources/jdbc.properties");
				FileInputStream fis = new FileInputStream(src);
				// to read the property file create an object of property class

				Properties pro = new Properties();

				pro.load(fis);
				String driver = pro.getProperty("driver");
				String dburl = pro.getProperty("dbURL");
				String user = pro.getProperty("username");
				String password = pro.getProperty("password");

				Class.forName(driver);

				conn = DriverManager.getConnection(dburl, user, password);

				conn.commit();

			} catch (FileSystemNotFoundException fe) {
				throw new LoanExceptions("unable to find Properties file" + fe.getMessage());
			} catch (ClassNotFoundException ce) {
				throw new LoanExceptions("Driver Class not found" + ce.getMessage());
			} catch (IOException ie) {
				throw new LoanExceptions("Problem occured while reading program" + ie.getMessage());
			} catch (SQLException se) {
				throw new LoanExceptions("problem occured while connecting" + se.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(" not working");
			}

		}

		return conn;
	}
}
