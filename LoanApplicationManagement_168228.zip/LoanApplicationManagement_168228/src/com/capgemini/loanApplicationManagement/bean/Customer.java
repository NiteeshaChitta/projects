package com.capgemini.loanApplicationManagement.bean;

public class Customer {
 private double custId;
 private String custName;
 private String address;
 private String mobile;
 private String email;
public double getCusId() {
	return custId;
}
public void setCusId(double d) {
	this.custId = d;
}
public String getCusName() {
	return custName;
}
public void setCusName(String cusName) {
	this.custName = cusName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String phno) {
	this.mobile = phno;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
}
