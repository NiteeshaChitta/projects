package com.capgemini.loanApplicationManagement.dao;

import com.cg.bean.CustomerDto;
import com.cg.bean.LoanDto;
import com.cg.exceptions.LoanExceptions;

public interface ICustDao {
	public LoanDto applyLoan(LoanDto loan) throws LoanExceptions;

	public Customer InsertCust(Customer c1) throws LoanExceptions;
}
