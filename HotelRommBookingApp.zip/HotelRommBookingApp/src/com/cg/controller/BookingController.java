/**
 * 
 */
package com.cg.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.BookingDetails;
import com.cg.bean.HotelDetails;
import com.cg.service.IBookingService;


@Controller
public class BookingController {
	@Autowired
	IBookingService ibs;
	
	
	
	@RequestMapping("/allHotel")
	public String all(Model m) {

		List<HotelDetails> lis = ibs.getAllHotels();
		if (!lis.isEmpty()) {
			m.addAttribute("trainee", lis);
			return "allHotels";
		} else {
			m.addAttribute("msg", "No Record Found");
			m.addAttribute("go", "success.jsp");
			return "error";
		}

	}
	
	
	
	@RequestMapping(value="/book" ,method=RequestMethod.POST)
	public String saveTrainee(Integer userid, String cname, Integer hotelid, Date todate, Date fromdate, Integer rooms,Model m) {
		BookingDetails tr=new BookingDetails(userid, cname, hotelid, todate,fromdate,rooms);
		HotelDetails hd =ibs.getHnameBYId(hotelid);
		ibs.addBooking(tr);
		m.addAttribute("hname",hd.getName());
		return "BookingConfirmation";
	}
	
	
	
	
	
	
}
