/**
 * 
 */
package com.cg.exception;

/**
 * @author YagniMurali
 *
 */
public class HotelBookingException extends Exception{
	public HotelBookingException(String msg) {
		super(msg);
	}

}
