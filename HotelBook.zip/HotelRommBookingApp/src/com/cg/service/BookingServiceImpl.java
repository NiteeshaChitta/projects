/**
 * 
 */
package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.BookingDetails;
import com.cg.bean.HotelDetails;
import com.cg.dao.IBookingDao;

/**
 * @author YagniMurali
 *
 */
@Service
@Transactional
public class BookingServiceImpl implements IBookingService{
	
	@Autowired
	IBookingDao ibd;

	@Override
	public List<HotelDetails> getAllHotels() {
		return ibd.getAllHotels();
	}

	@Override
	public void addBooking(BookingDetails tr) {
		ibd.addBooking(tr);
		
	}

	@Override
	public HotelDetails getHnameBYId(Integer hotelid) {
		return ibd.getHnameBYId(hotelid);
	}

}
