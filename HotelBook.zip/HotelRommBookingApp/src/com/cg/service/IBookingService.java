/**
 * 
 */
package com.cg.service;

import java.util.List;

import com.cg.bean.BookingDetails;
import com.cg.bean.HotelDetails;

/**
 * @author YagniMurali
 *
 */
public interface IBookingService {

	List<HotelDetails> getAllHotels();

	void addBooking(BookingDetails tr);

	HotelDetails getHnameBYId(Integer hotelid);

}
