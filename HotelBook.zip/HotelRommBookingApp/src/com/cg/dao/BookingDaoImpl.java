/**
 * 
 */
package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.BookingDetails;
import com.cg.bean.HotelDetails;


/**
 * @author YagniMurali
 *
 */
@Repository
public class BookingDaoImpl implements IBookingDao{
	
	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public List<HotelDetails> getAllHotels() {
		TypedQuery<HotelDetails> query = entitymanager.createQuery("SELECT d FROM HotelDetails d", HotelDetails.class);
		return query.getResultList();
	}

	@Override
	public void addBooking(BookingDetails tr) {
		entitymanager.persist(tr);
		entitymanager.flush();
		
	}

	@Override
	public HotelDetails getHnameBYId(Integer hotelid) {
		
		return entitymanager.find(HotelDetails.class, hotelid);
	}

}
