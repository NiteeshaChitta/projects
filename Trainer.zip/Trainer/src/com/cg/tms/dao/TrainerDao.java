package com.cg.tms.dao;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.exception.TrainerManageException;

public interface TrainerDao {
	public int addTrainerDetails(TrainerDetails details) throws TrainerManageException;

}
