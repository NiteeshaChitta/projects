package com.cg.tms.dao;

public interface IQueryMapper {
	
	static String INSERT_QUERY = "INSERT INTO trainer_details VALUES(Trainer_Id_Seq.nextval,?,?,?,?,?)";
	static String GET_TRAINER_ID = "SELECT Trainer_Id_Seq.CURRVAL FROM DUAL";
	
}
