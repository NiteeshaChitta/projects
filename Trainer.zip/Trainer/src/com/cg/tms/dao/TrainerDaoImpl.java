package com.cg.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;






import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.exception.TrainerManageException;
import com.cg.tms.util.DBConnecton;

public class TrainerDaoImpl implements TrainerDao {
	
	static Connection conn;

	@Override
	public int addTrainerDetails(TrainerDetails details)
			throws TrainerManageException {
		

		PreparedStatement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();

			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1, details.getName());
			insertStmt.setString(2, details.getLocation());
			insertStmt.setString(3, details.getDesignation());
			insertStmt.setString(4, details.getTechnology());
			insertStmt.setString(5, details.getContactNo());
			
			/*
			 * System.out.println(pd.getCustomerName()); System.out.println(pd.getMailId());
			 * System.out.println(pd.getPhoneNumber());
			 * System.out.println(pd.getPurchasedate());
			 * System.out.println(pd.getMobileId());
			 */

			int result = insertStmt.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new TrainerManageException("Sorry! insert not performed");
			} else {
				conn.commit();
			}

		} catch (SQLException | NullPointerException e) {

			throw new TrainerManageException(e.getMessage());
		}
int trainer = getTrainerId();
		return trainer;
	}
	
	
	public int getTrainerId() throws TrainerManageException{
		
		PreparedStatement getPurchseStmt = null;
		ResultSet purchaseIdResult = null;
		int purchaseid = 0;
		try {
			conn = DBConnecton.getConnection();
			getPurchseStmt = conn.prepareStatement(IQueryMapper.GET_TRAINER_ID);
			purchaseIdResult = getPurchseStmt.executeQuery();
			if (purchaseIdResult.next()) {
				purchaseid = purchaseIdResult.getInt(1);
				//logger.info("Registation done: " + purchaseid);
			}
		} catch (TrainerManageException e) {
			throw new TrainerManageException("Sorry purchseid not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new TrainerManageException("Sorry purchseid sql exception genrated");

		}

		return purchaseid;
		
		
	}
	
	

}
