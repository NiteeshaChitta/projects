package com.cg.tms.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystemNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;




import com.cg.tms.exception.TrainerManageException;

public class DBConnecton {
	static Connection conn = null;

	public static Connection getConnection() throws TrainerManageException {
		if (conn == null) {
			try {
				File src = new File("Resources/jdbc.properties");
				FileInputStream fis = new FileInputStream(src);
				// to read the property file create an object of property class

				Properties pro = new Properties();

				pro.load(fis);
				String driver = pro.getProperty("driver");
				String dburl = pro.getProperty("dbURL");
				String user = pro.getProperty("username");
				String password = pro.getProperty("password");

				Class.forName(driver);

				conn = DriverManager.getConnection(dburl, user, password);

				conn.commit();

			} catch (FileSystemNotFoundException fe) {
				throw new TrainerManageException("unable to find Properties file" + fe.getMessage());
			} catch (ClassNotFoundException ce) {
				throw new TrainerManageException("Driver Class not found" + ce.getMessage());
			} catch (IOException ie) {
				throw new TrainerManageException("Problem occured while reading program" + ie.getMessage());
			} catch (SQLException se) {
				throw new TrainerManageException("problem occured while connecting" + se.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(" not working");
			}

		}

		return conn;
	}
}
