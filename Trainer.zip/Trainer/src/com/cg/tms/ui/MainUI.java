package com.cg.tms.ui;

import java.util.Scanner;



import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.exception.TrainerManageException;
import com.cg.tms.service.TrainerService;
import com.cg.tms.service.TrainerServiceImpl;

public class MainUI {
	
	private static Scanner in;
	static TrainerService its = new TrainerServiceImpl();
	
	
		public static void main(String[] args) throws TrainerManageException {

			in = new Scanner(System.in);
			System.out.println(" \nWelcome to Trainer Booking portal\n");
			while (true) {
				System.out.println(" \nEnter your choice:\n");
				System.out.println(" 1.Add trainer info to existing table\n");
				
				System.out.println(" 2.Exit\n");
				int choice = in.nextInt();
				switch (choice) {

				case 1:
					getInputs();
					break;

				case 2:
					System.out.println("\n\nThank you");
					System.exit(0);

				}

			}

		}

		private static void getInputs() throws TrainerManageException {
			String trainerName;
			String trLocation = "";
			String trDesignatin= "";
			String technology= "";
			String contactNumber;
			
			 TrainerDetails tb = new TrainerDetails();
			
			while (true) {
				
				System.out.println("Enter trainerName ");

				trainerName = in.next();

				if (its.validateTrainerName(trainerName)) {
					break;
				} else {
					System.out.println("Invalid, should be [A-Z] and 6 digits ");
				}
			}
			
			
			System.out.println("Select tainer location");
			System.out.println("1.Hydrabad");
			System.out.println("2.chennai");
			System.out.println("3.Pune");
			System.out.println("4.Banglore");
			System.out.println("5.Mumbai");
			
			int loc = in.nextInt();
			switch(loc){
			case 1:
				trLocation = "Hydrabad";
				
			case 2:
				trLocation = "chennai";
				
			case 3:
				trLocation = "Pune";
				
			case 4:
				trLocation = "Banglore";
				
			case 5:
				trLocation = "Mumbai";
			
			}
			
			
			
			System.out.println("Select tainer Designation");
			System.out.println("1.consultent");
			System.out.println("2.senior consultent");
			int disg = in.nextInt();
			switch(disg){
			case 1:
				trDesignatin = "consultent";
				
			case 2:
				trDesignatin = "senior consultent";
			
			}
			
			
			System.out.println("Select tainer Technology");
			System.out.println("1.jee");
			System.out.println("2.cloud");
			System.out.println("3.mainframes");
			
			int tech = in.nextInt();
			switch(tech){
			case 1:
				technology = "jee";
				
			case 2:
				technology = "cloud";
				
			case 3:
				technology = "mainframes";
			
			}
			
			
			
			while (true) {
				
				System.out.println("Enter trainer Contact number");

				contactNumber = in.next();

				if (its.validateMobNumber(contactNumber)) {
					break;
				} else {
					System.out.println("Invalid, must be 10 digit ");
				}
			}
			
			
			
			
			
			tb.setName(trainerName);
			tb.setLocation(trLocation);
			tb.setDesignation(trDesignatin);
			tb.setTechnology(technology);
			tb.setContactNo(contactNumber);
			
			int trainerid = its.addTrainerDetails(tb);
			System.out.println("information stored seuss id: "+trainerid);
			
			
			
			
			
			
		}
		

}
