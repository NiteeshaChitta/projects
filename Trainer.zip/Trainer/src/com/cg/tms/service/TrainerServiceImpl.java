package com.cg.tms.service;

import java.util.regex.Pattern;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.dao.TrainerDao;
import com.cg.tms.dao.TrainerDaoImpl;
import com.cg.tms.exception.TrainerManageException;

public class TrainerServiceImpl implements TrainerService{
	
	TrainerDao ts;

	@Override
	public int addTrainerDetails(TrainerDetails details) throws TrainerManageException {
		
		ts =new TrainerDaoImpl();
	int	trainer = ts.addTrainerDetails(details);
	
		return trainer;
	}

	@Override
	public boolean validateMobNumber(String PhoneNumber) {
		String patterns1 = "\\d{10}";
		if (Pattern.matches(patterns1, PhoneNumber)) {
			return true;
		} else {

			return false;
		}
	}

	@Override
	public boolean validateTrainerName(String trainer) {
		String patterns = "[A-Z][a-z ]{5,20}";
		if (Pattern.matches(patterns, trainer)) {
			return true;
		} else {
			return false;
		}
	}

}
