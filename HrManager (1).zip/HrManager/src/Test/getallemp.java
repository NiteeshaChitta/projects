package Test;

import java.util.List;

import com.myapp.dao.oracle.EmployeeOracleDao;
import com.myapp.entity.employees;
import com.myapp.services.impl.EmployeeServiceImpl;

public class getallemp {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
//		EmployeeOracleDao emp=new EmployeeOracleDao();
		//List<employees> li = emp.getAllEmployees();
	//	List<employees> li=emp.getEmployeesByDepartment(90);
		//employees e=emp.getEmployeeById(229);
//		
//		System.out.println(e);
//	List<employees> li = emp.getEmployeesByJobId("AD_ASST");
//		for(employees e : li){
//			System.out.println(e);
//		}
		
//		employees e1=new employees(229, "kiran", "marni", "kiran021997@gmail.com", "9490104628", "12-DEC-2018", "AC_MGR", 50000, .24, 101, 110);
//		emp.addEmployee(e1);
//		
//		emp.updateEmployee(e1);
	//	emp.deleteEmployee(229);
		
		EmployeeServiceImpl emp=new EmployeeServiceImpl();
		employees e1=new employees(229, "kiran", "marni", "kiran021997@gmail.com", "9490104628", "12-DEC-2018", "AC_MGR", 50000, .24, 101, 110);
		emp.addEmployee(e1);
		employees e=emp.getEmployee(229);
		System.out.println(e);
		
	}

}
