package Test;

import java.util.List;

import com.myapp.dao.oracle.DepartmentOracleDao;
import com.myapp.entity.departments;

public class getalldept {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		DepartmentOracleDao dao=new DepartmentOracleDao();
		List<departments> li = dao.getDepartmentsByLocationId(1700);
//		List<departments> li = dao.getAllDepartments();
		
		for(departments d : li){
			System.out.println(d);
		}

	}

}
