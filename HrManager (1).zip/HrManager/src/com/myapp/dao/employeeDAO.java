package com.myapp.dao;

import java.util.List;

import com.myapp.entity.*;

public interface employeeDAO {
	List<employees> getAllEmployees() throws Exception;

	List<employees> getEmployeesByDepartment(int departmentId) throws Exception;

	List<employees> getEmployeesByJobId(String jobId) throws Exception;

	employees getEmployeeById(int employeeId) throws Exception;

	employees getEmployeeByEmail(String email) throws Exception;

	void addEmployee(employees e) throws Exception;

	void updateEmployee(employees e) throws Exception;

	void deleteEmployee(int employeeId) throws Exception;

}
