package com.myapp.presentation;

import java.util.Scanner;

import com.myapp.entity.employees;
import com.myapp.services.impl.EmployeeServiceImpl;

public class ClintUI {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean flag = true;
		int choice = 0;
		
		while (flag) {
			System.out.println("Enter '1' to getEmployeeDetails");
			System.out.println("Enter '2' to ADD Employee");
			System.out.println("Enter '3' to UPDATE Employee");
			System.out.println("Enter '4' to DELETE Employee");
			System.out.println("Enter '5' to EXIT");
			
			choice = sc.nextInt();
			if (choice >= 1 && choice <= 5) {
				flag = false;
				
			} else {
				System.out.println("Please Choose Correct Operation");
			}
		}

		switch (choice) {
		case 1:
			getEmployee();
			break;
		case 2:
			addEmployee();
			break;
		case 3:

			break;
		case 4:

			break;

		default:
			break;
		}

	}

	private static void addEmployee() {
		// TODO Auto-generated method stub
		System.out.println("Enter Employee ID");
		int employeeId=sc.nextInt();
		System.out.println("Enter First Name");
		String fname=sc.next();
		System.out.println("Enter Last Name");
		
		String lname=sc.next();
		System.out.println("Enter Email ");
		String email=sc.next();
		System.out.println("Enter Phone Number");
		String phonumber=sc.next();
		System.out.println("Enter Hire Date(ex : 01-JAN-2019)");
		String hiredate=sc.next();
		System.out.println("Enter Job ID");
		String jobId=sc.next();
		System.out.println("Enter Salary");
		double Salary=sc.nextDouble();
		System.out.println("Enter Comission PCT");
		double comissionpct=sc.nextDouble();
		System.out.println("Enter Manager ID");
		int managerid=sc.nextInt();
		System.out.println("Enter Department ID");
		int deptid=sc.nextInt();
		
		employees e1=new employees(employeeId, fname, lname, email, phonumber, hiredate, jobId, Salary, comissionpct, managerid, deptid);
		EmployeeServiceImpl emp=new EmployeeServiceImpl();
		try{
		emp.addEmployee(e1);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private static void getEmployee() {
		// TODO Auto-generated method stub

		try {
			
			int employeeId=0;
			System.out.println("Enter EMPLOYEE ID to get Details");
			employeeId =sc.nextInt();
			EmployeeServiceImpl emp = new EmployeeServiceImpl();
			employees e = emp.getEmployee(employeeId);
			if (e != null) {
				System.out.println("Employee ID : " + e.getEmployeeId());
				System.out.println("Name : " + e.getFirstName() + " "
						+ e.getLastName());
				System.out.println("Mobile NUmber : " + e.getPhoneNumber());
				System.out.println("Email : " + e.getEmail());
			} else {
				System.out.println("No Record Found For Employee ID : "
						+ employeeId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
