package com.myapp.datasource;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Queue;

public class ConnectionPool {
	private String userName;
	private String password;
	private String url;
	private int maxConnection;
	private int openConnection;
	private List<Connection> usedConnections = new ArrayList<Connection>();
	private Queue<Connection> freeConnections = new LinkedList<Connection>();
	private static ConnectionPool connectionPool;

	private ConnectionPool(String fileName) throws Exception {
		FileInputStream fis = new FileInputStream(fileName);
		Properties prop = new Properties();
		prop.load(fis);

		String driver = prop.getProperty("driver");
		url = prop.getProperty("url");

		userName = prop.getProperty("user");
		password = prop.getProperty("password");

		String max = prop.getProperty("maxConnection");
		maxConnection = Integer.parseInt(max);

		Class.forName(driver);
		fis.close();
	}

	public static ConnectionPool getConnectionPool(String fileName) throws Exception {
		if(connectionPool==null){
			connectionPool=new ConnectionPool(fileName);
			return connectionPool;
		}
		return connectionPool;

	}

	private Connection openNewConnection() throws Exception {
		Connection conn=DriverManager.getConnection(url, userName, password);
		ManagedConnection connection=new ManagedConnection(this, conn);
		openConnection++;
		return connection;
		

	}

	public synchronized Connection getConnection() throws Exception {
		Connection conn=null;
		if(!freeConnections.isEmpty()){
			conn=freeConnections.poll();
		}else{
			if(openConnection < maxConnection){
				conn=openNewConnection();
			}else{
				throw new SQLException("No More New Connections available...");
			}
		}
		usedConnections.add(conn);
		return conn;

	}

	public synchronized void returnConnection(Connection conn) {
		usedConnections.remove(conn);
		freeConnections.add(conn);
	}

}
