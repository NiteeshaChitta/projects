package com.myapp.entity;

public class countries {
	private String countryId;
	private String sountryName;
	private int regionId;
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getSountryName() {
		return sountryName;
	}
	public void setSountryName(String sountryName) {
		this.sountryName = sountryName;
	}
	public int getRegionId() {
		return regionId;
	}
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((countryId == null) ? 0 : countryId.hashCode());
		result = prime * result + regionId;
		result = prime * result
				+ ((sountryName == null) ? 0 : sountryName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		countries other = (countries) obj;
		if (countryId == null) {
			if (other.countryId != null)
				return false;
		} else if (!countryId.equals(other.countryId))
			return false;
		if (regionId != other.regionId)
			return false;
		if (sountryName == null) {
			if (other.sountryName != null)
				return false;
		} else if (!sountryName.equals(other.sountryName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "countries [countryId=" + countryId + ", sountryName="
				+ sountryName + ", regionId=" + regionId + "]";
	}
	public countries(String countryId, String sountryName, int regionId) {
		super();
		this.countryId = countryId;
		this.sountryName = sountryName;
		this.regionId = regionId;
	}
	public countries() {
		// TODO Auto-generated constructor stub
	}

}
