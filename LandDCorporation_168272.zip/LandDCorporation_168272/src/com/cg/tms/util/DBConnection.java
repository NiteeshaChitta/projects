package com.cg.tms.util;
import java.io.*;
import java.sql.*;
import java.util.Properties;

import com.cg.tms.exception.TrainerException;

public class DBConnection {
	public static Connection conn = null;
	
	/**********************************************************************
	 * Method Name 		: getConnection() 
	 * Input Parameters :  
	 * Return type 		: DBConnection instance
	 * Description 		: Returns connection object
	 ************************************************************************/

	public static Connection getConnection() throws TrainerException {
	
		if (conn == null) {
			try {
				File src = new File("Resources/jdbc.properties"); 	// to access property file
				FileInputStream fis = new FileInputStream(src); 	// taking filE into stream
				Properties pro = new Properties(); 					// to read property file Create properties object
				pro.load(fis); 										// load fis to properties

				String driver = pro.getProperty("driver");
				String dburl = pro.getProperty("dbURL");
				String user = pro.getProperty("username");
				String pass = pro.getProperty("password");
				Class.forName(driver);
				conn = DriverManager.getConnection(dburl, user, pass);
				conn.commit();
			} catch (FileNotFoundException fe) {
				throw new TrainerException(
						"Unable to find property file" + fe);
			} catch (ClassNotFoundException ce) {
				throw new TrainerException(
						"Unable to find the Class" + ce);
			} catch (IOException ie) {
				throw new TrainerException(
						"Io exception occured while connecting to SQL" + ie);
			} catch (SQLException se) {
				throw new TrainerException(
						"Unable to connect SQL" + se);
			}
		}
		return conn;
	}
}
