package com.cg.tms.service;

import java.util.regex.Pattern;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.dao.TrainerDaoImpl;
import com.cg.tms.exception.TrainerException;

public class TrainerServiceImpl implements TrainerService
{
TrainerDaoImpl daoObj;
	
	// constructor 
	public TrainerServiceImpl()
	{
		daoObj = new TrainerDaoImpl();
	}
	
	
	
	public int addTrainerDetails(TrainerDetails details)  throws TrainerException
	{
		return daoObj.addTrainerDetails(details);
	}
	
	public long getAppointmentID() throws TrainerException
	{
		return daoObj.getAppointmentID();
	}
	
	
	// this method validates User name
		public boolean validateName(String str)
		{
	    String namePattern = "[A-Za-z ]{6,20}";
		if(Pattern.matches(namePattern,str))
			return true;
		else
			return false;
		}
		
		// this method validates User phone number
		public boolean validatePhoneNumber(String str)
		{
			if(Pattern.matches("[7-9][0-9]{9}",str))
				return true;
			else
				return false;	
		}
		
		// this method validates given mobile id 
		public boolean validateMobileId(long mobId)
		{
			String str = Long.toString(mobId);
		if(Pattern.matches("\\d{4}",str))
			return true;
		else
			return false;
		}
		
				
}
