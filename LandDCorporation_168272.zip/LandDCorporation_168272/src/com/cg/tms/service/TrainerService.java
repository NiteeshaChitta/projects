package com.cg.tms.service;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.exception.TrainerException;

public interface TrainerService {
	
	public int addTrainerDetails(TrainerDetails details)  throws TrainerException;
}
