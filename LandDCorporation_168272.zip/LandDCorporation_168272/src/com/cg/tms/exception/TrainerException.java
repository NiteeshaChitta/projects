package com.cg.tms.exception;

public class TrainerException extends Exception {
	public TrainerException(String msg)
	{
		super(msg);
	}
}
