package com.cg.tms.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO trainer_details values(Trainer_Id_Seq.nextval,?,?,?,?,?)";
	public static final String GET_TID="SELECT Trainer_Id_Seq.CURRVAL FROM DUAL";
}
