package com.cg.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.exception.TrainerException;
import com.cg.tms.util.DBConnection;


public class TrainerDaoImpl implements TrainerDao 
{
	private Logger logger = Logger.getLogger(TrainerDaoImpl.class);
	public TrainerDaoImpl()
	{
	PropertyConfigurator.configure("log4j.properties");
	}

	public int addTrainerDetails(TrainerDetails details) throws TrainerException
	{
		
		logger.info("Customer registration started");
		Connection conn;
		PreparedStatement insertStmt = null;
		try
		{	
			conn=DBConnection.getConnection();
			insertStmt=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1,details.getTrainerName());
			insertStmt.setString(2,details.getLocation());
			insertStmt.setString(3,details.getDesignation());
			insertStmt.setString(4,details.getTechnology());
			insertStmt.setString(5,details.getContactNum());
			
			int result = insertStmt.executeUpdate();
			logger.info("statement to add trainer details executed");
			
			if(result!=1)
			{
				logger.info("value not inserted");
				throw new TrainerException("sorry, cant process the request");
			}
			
			else
			{
				conn.commit();
			}
		}
		catch(TrainerException e)
		{
			throw new TrainerException("sorry not updated");
		}
		catch(SQLException e)
		{
			throw new TrainerException("sorry not updated");
		}
		
		return 0;
		
	}
	
	
	public long getAppointmentID() throws TrainerException {
		Connection conn;
		long val=0;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement=null;	
		
		
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_TID);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				val=resultSet.getLong(1);
			}
		}
		catch(SQLException e)
		{
			throw new TrainerException("sorry not updated");
		}
		catch(TrainerException e)
		{
			throw new TrainerException("sorry not updated");
		}
		
		return val;
	}
	
	
}

