package com.cg.tms.ui;

import java.util.Scanner;

import com.cg.tms.beans.TrainerDetails;
import com.cg.tms.dao.TrainerDaoImpl;
import com.cg.tms.exception.TrainerException;
import com.cg.tms.service.TrainerServiceImpl;


public class MainUI {
	private static Scanner in;
	static TrainerServiceImpl service= new TrainerServiceImpl();
	public static void main(String[] args) throws TrainerException
	{
		in = new Scanner(System.in);
		System.out.println("Welocome To Trainer Regsitration Portal");
		String choice = "null";
		
		while (!choice.equals("2")) {
			System.out.println("****** Enter your choice *******");
			System.out.println("-----------------------------------");
			System.out.println("1) Add trainer information to existing table ");
			System.out.println("2) EXIT ");
			System.out.println("-----------------------------------");
			choice = in.next().trim();
			switch (choice) 
			{
			case "1": 
					getInputs();
					System.out.println("Thank you for registering.....!\n");
					break;
			case "2":
				System.out.println("Thank you.... Program terminated");
				System.exit(0);
				break;
				
			default:
				System.out.println("WRONG CHOICE chosen...Please enter a valid choice\n");
			}
		}
		System.out.println("Thank you.... program terminated");
	}
	
	
	
	private static void getInputs() throws TrainerException {
		TrainerDetails dtoOBJ = new TrainerDetails();
		TrainerServiceImpl serv= new TrainerServiceImpl();
		String trainerName="?";
		String contactNum="";
		boolean status=true;
		int count=4;
		
		while(status)
		{
			System.out.println("Enter Trainer Name");
			trainerName=in.next();
			if(serv.validateName(trainerName)==true)
			{
				dtoOBJ.setTrainerName(trainerName); status=true; break;
			}
			else
			{
			System.out.println("Name should be only alphabets and should be between 5 to 20 charactors.. enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		
		while(status)
		{
			System.out.println("Select tariner location from given values ");
			System.out.println("1.Hyderabad \n 2.Chennai \n 3.Pune \n 4.Bangalore \n 5.Mumbai ");
			 String ch = in.next().trim();
			 switch (ch) 
				{
				case "1": dtoOBJ.setLocation("Hyderabad"); status=false;   
						 break;
				case "2": dtoOBJ.setLocation("Chennai");   status=false;
				 break;
				case "3": dtoOBJ.setLocation("Pune");   status=false;
				 break;
				case "4": dtoOBJ.setLocation("Bangalore");   status=false;
				 break;
				case "5": dtoOBJ.setLocation("Mumbai");   status=false;
				 break;			
				default:
					System.out.println("WRONG CHOICE chosen...Please enter a valid choice\n");
				}
		}
		status=true;
		
		while(status)
		{
			System.out.println("Select tariner designation ");
			System.out.println("1.Consultant \n 2.senior Consultant ");
			 String ch = in.next().trim();
			 switch (ch) 
				{
				case "1": dtoOBJ.setDesignation("senior Consultant"); status=false;   
						 break;
				case "2": dtoOBJ.setDesignation("consultant");   status=false;
				 			break;			
				default:
					System.out.println("WRONG CHOICE chosen...Please enter a valid choice\n");
				}
		}
		
		status=true;
		while(status)
		{
			System.out.println("Select technology ");
			System.out.println("1.jee \n 2.cloud \n 3.mainframes");
			 String ch = in.next().trim();
			 switch (ch) 
				{
				case "1": dtoOBJ.setTechnology("jee"); status=false;   
						 break;
				case "2": dtoOBJ.setTechnology("cloud");   status=false;
				 break;
				case "3": dtoOBJ.setTechnology("mainframes");   status=false;
				 break;			
				default:
					System.out.println("WRONG CHOICE chosen...Please enter a valid choice\n");
				}
		}
		status=true;
		
		count=4;
		while(status)
		{
			System.out.println("Enter customer mobile number");
			contactNum=in.next();
			if(serv.validatePhoneNumber(contactNum)==true)
			{
				dtoOBJ.setContactNum(contactNum);status=true; break;
			}
			else
			{
			System.out.println("Wrong mobile number given... Enter again");
			count--;
			if(count==0) status=false;
			}
		}
		
		
		if(status==true)
		{
			serv.addTrainerDetails(dtoOBJ);
			System.out.println("\nTrainer Information stored successfully with the id: " + serv.getAppointmentID());
		}
				else
			System.out.println("Sorry....You ran out of given chances\n");
	}
}
